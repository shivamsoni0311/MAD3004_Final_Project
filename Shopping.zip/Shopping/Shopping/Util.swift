//
//  Util.swift
//  Shopping
//
//  Created by Jigisha Patel on 2018-07-20.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

class Util{
    static func drawLine()
    {
        let line = String(repeating: "-", count: 100)
        print(line)
    }
}
