//
//  Test.swift
//  Shopping
//
//  Created by Jigisha Patel on 2018-07-25.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation



//class Product {
//    let productID: Int?
//    let productDescription: String?
//    let productPrice: Double?
//
//    init(productID: Int, productDescription: String, productPrice: Double) throws {
//        if productID <= 0 {
//            throw ProductError.InvalidProductID
//        } else if productPrice < 10000 {
//            throw ProductError.InvalidProductPrice(productID)
//        }
//        self.productID = productID
//        self.productDescription = productDescription
//        self.productPrice = productPrice
//    }
//
//}

//do {
//    let product = try Product(productID: 1 , productDescription: "Television", productPrice: 5000.0)
//    print(product)
//} catch {
//    print("Error :\(error)") // Error :Invalid product price for product id :: 1
//}
