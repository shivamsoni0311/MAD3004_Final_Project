//
//  DataHelper.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper {
    var EmployeeList = [Int : Employee]()
    var FlightList = [Int : Flight]()
    
    init(){
        self.loadEmployeeData()
        self.loadFlightData()
    }
    
    func loadEmployeeData(){
        EmployeeList = [:]
        
        let employee1 = Employee(employeeID: 1,employeeName: "Saloni",employeeEmail:"s@g.com",employeeMobile:"45678945787",employeeAddress:"Scarborough",employeeDesignation:"Pilot",employeeSinNumber:"4578787454547")
        EmployeeList[employee1.EmployeeID!]=employee1
        
        let employee2 = Employee(employeeID: 2,employeeName: "Shivam",employeeEmail:"shivam@g.com",employeeMobile:"457895558885",employeeAddress:"Scarborough",employeeDesignation:"Pilot",employeeSinNumber:"787874548778")
        EmployeeList[employee2.EmployeeID!]=employee2
    }
    
    func displayEmployee(){
        for (_,value) in self.EmployeeList.sorted(by:  { $0.key < $1.key})
        {
            print(value.displayData())
        }
    }
    
    func loadFlightData(){
        FlightList = [:]
        
        let f1 = Flight(flightID: 101, flightFrom: "Mumbai", flightTo: "Toronto", flightDate: "4th Sept 2018", airlineID: 01, airlineName: "Air Canada", pilotName: "Shivam Soni" )
        FlightList[f1.FlightID!] = f1
        
        let f2 = Flight(flightID: 102, flightFrom: "Toronto", flightTo: "Calgary", flightDate: "8th October 2018", airlineID: 101, airlineName: "Air Canada", pilotName: "Saloni Parekh")
        FlightList[f2.FlightID!] = f2
        
        let f3 = Flight(flightID: 103, flightFrom: "Ahmedabad", flightTo: "Sydeny", flightDate: "22 November 2018", airlineID: 102, airlineName: "Quantas", pilotName: "Alay Desai")
        FlightList[f3.FlightID!] = f3
        
        let f4 = Flight(flightID: 104, flightFrom: "Delhi", flightTo: "New York", flightDate: "25th December 2018", airlineID: 103, airlineName: "British Airways", pilotName: "Alex Smith")
        FlightList[f4.FlightID!] = f4
        
        let f5 = Flight(flightID: 105, flightFrom: "Colombo", flightTo: "Nairobi", flightDate: "3rd Sept 2018", airlineID: 104, airlineName: "Garuda Airways", pilotName: "Vijay Thaniglasa")
        FlightList[f5.FlightID!] = f5
        
        let f6 = Flight(flightID: 106, flightFrom: "Mumbai", flightTo: "Vancouver", flightDate: "4th Sept 2018", airlineID: 101, airlineName: "Air Canada", pilotName: "Shivam Soni")
        FlightList[f6.FlightID!] = f6
        
        let f7 = Flight(flightID: 107, flightFrom: "Chennai", flightTo: "London", flightDate: "15 November 2018", airlineID: 103, airlineName: "British Airways", pilotName: "Ricka Lendsom")
        FlightList[f7.FlightID!] = f7
        
        let f8 = Flight(flightID: 108, flightFrom: "Paris", flightTo: "Huston", flightDate: "20 January 2019", airlineID: 105, airlineName: "Air France", pilotName: "Robert Clove")
        FlightList[f8.FlightID!] = f8
        
        let f9 = Flight(flightID: 109, flightFrom: "Montreal", flightTo: "Edmonton", flightDate: "4th August 2018", airlineID: 101, airlineName: "Air Canada", pilotName: "Micheal Clarck")
        FlightList[f9.FlightID!] = f9
        
        let f10 = Flight(flightID: 110, flightFrom: "Toronto", flightTo: "Montreal", flightDate: "4th Sept 2018", airlineID: 101, airlineName: "Air Canada", pilotName: "Dhyanee Bhatt")
        FlightList[f10.FlightID!] = f10
    }
    
    func displayFlightdata(){
        for (_, value) in self.FlightList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print(value.displayData())
        }
      Util.drawLine()
}
    func searchFlight(flightID : Int) -> Flight?{
        if FlightList[flightID] != nil{
            return FlightList[flightID]! as Flight
        }
        else{
            print("Sorry..The flight you have select is not available")
            return nil
        }
    }
    
}
