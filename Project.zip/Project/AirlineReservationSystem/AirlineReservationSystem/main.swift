//
//  main.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Welcome to Airline Reservation System!")

/*var Saloni = Employee()
Saloni.employeeID = 1
Saloni.EmployeeName="Saloni"
Saloni.Email="s@g.com"
Saloni.Mobile="123456789"
Saloni.Address="Scarborough"
Saloni.Designation="Pilot"
Saloni.SIN="456-456-4578"
print(Saloni.displayData())

var saloni=EmployeeList()
saloni.displayEmployee()*/

var choice = 1
let dataHelper = DataHelper()
var reservation = Reservation()
var passenger =  Passenger()

while choice != 6{
    print("\n Book Your Flight Ticket Now!!!")
    print("\t 1: Make An Enquiry")
    print("\t 2: Book Ticket")
    print("\t 3: Show Tickets")
    print("\t 4: Cancel Ticket")
    print("\t 5: Update Ticket")
    print("\t 6: Exit ")
    print("Enter your choice please :")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dataHelper.displayFlightdata()
    case 2:
        reservation.addFlight()
    case 3:
        print(reservation.displayData())
    default:
        print("Please enter valid menu option.")
    }
}









