//
//  Employee.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Employee : IDisplay{
    
    var employeeID : Int?
    private var employeeName: String?
    private var employeeEmail: String?
    private var employeeMobile: String?
    private var employeeAddress : String?
    private var employeeDesignation : String?
    private var employeeSinNumber : String?
    
    var EmployeeID : Int?{
        get{return self.employeeID}
        set{self.employeeID=newValue}
    }
    
    var EmployeeName : String?{
        get{
            return self.employeeName
        }
        
        set{
            self.employeeName = newValue
            //newvalue variable is by default available in set method
        }
    }
    var Email : String?{
        get{
            return self.employeeEmail
        }
        
        set{
            self.employeeEmail = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    var Mobile : String?{
        get{
            return self.employeeMobile
        }
        
        set{
            self.employeeMobile = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    var Address : String?{
        get{
            return self.employeeAddress
        }
        
        set{
            self.employeeAddress = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    var Designation : String?{
        get{
            return self.employeeDesignation
        }
        
        set{
            self.employeeDesignation = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    var SIN : String?{
        get{
            return self.employeeSinNumber
        }
        
        set{
            self.employeeSinNumber = newValue
            //newvalue variable is by default available in set method
        }
    }
    
    init() {
        self.employeeID = 0
        self.employeeName=""
        self.employeeEmail=""
        self.employeeMobile=""
        self.employeeAddress=""
        self.employeeDesignation = ""
        self.employeeSinNumber=""
    }
    
    init(employeeID:Int,employeeName:String,employeeEmail:String,employeeMobile:String,employeeAddress:String,employeeDesignation:String,employeeSinNumber:String){
        self.employeeID=employeeID
        self.employeeName=employeeName
        self.employeeEmail=employeeEmail
        self.employeeAddress=employeeAddress
        self.employeeDesignation=employeeDesignation
        self.employeeSinNumber=employeeSinNumber
    }
     func displayData() -> String {
        var returnData = ""
        
     /*   if self.employeeID != nil{
            returnData += "\n Employee ID : " + self.employeeID!
        }
        
        
        if self.employeeName != nil{
            returnData += "\n Employee name : " + self.employeeName!
        }
        
        
        if self.employeeEmail != nil{
            returnData += "\n Employee Email : " + self.employeeEmail!
        }
        
        
        if self.employeeMobile != nil{
            returnData += "\n Employee Mobile : " + self.employeeMobile!
        }
        
        
        if self.employeeAddress != nil{
            returnData += "\n Employee Address : " + self.employeeAddress!
        }
        
        
        if self.employeeDesignation != nil{
            returnData += "\n Employee Desgnation : " + self.employeeDesignation!
        }
        
        if self.employeeSinNumber != nil{
            returnData += "\n Employee SIN Number : " + self.employeeSinNumber!
        }*/
        
        returnData += "\n Employee ID : \(self.employeeID ?? 0)"
        returnData += "\n Employee Name: \(self.employeeName ?? "")"
        returnData += "\n Employee Name: \(self.employeeEmail ?? "")"
        returnData += "\n Employee Name: \(self.employeeAddress ?? "")"
        returnData += "\n Employee Name: \(self.employeeDesignation ?? "")"
        returnData += "\n Employee Name: \(self.employeeSinNumber ?? "")"
      
        
        return returnData
        
    }
    
}
