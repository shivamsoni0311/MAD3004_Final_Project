//
//  Flight.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight: IDisplay {
    
    var flightID : Int?
    var flightFrom : String?
    var flightTo : String?
    var flightDate : String?
    var airlineName: String?
    var airlineID: Int?
    var pilotName: String?
   
    
    var FlightID : Int?{
        get{return self.flightID}
        set{self.flightID = newValue}
    }
    var FlightFrom : String?{
        get{return self.flightFrom}
        set{self.flightFrom = newValue}
    }
    var FlightTo : String?{
        get{return self.flightTo}
        set{self.flightTo = newValue}
    }
    var FlightDate : String?{
        get{return self.flightDate}
        set{self.flightDate = newValue}
    }
 var AirlineID : Int?{
        get{return self.airlineID}
        set{self.airlineID = newValue}
    }
    var AirlineName : String?{
        get{return self.airlineName}
        set{self.AirlineName = newValue}
    }
    var PilotName : String?{
        get{return self.pilotName}
        set{self.pilotName = newValue}
    }
    
     init() {
        self.flightID = 0
        self.flightFrom=""
        self.flightTo=""
        self.flightDate=""
        self.airlineID = 0
        self.airlineName = ""
        self.pilotName = ""
    }
    
    init(flightID: Int, flightFrom: String, flightTo: String, flightDate: String, airlineID: Int, airlineName: String, pilotName: String ) {
        self.flightID = flightID
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.flightDate = flightDate
        self.airlineID = airlineID
        self.airlineName = airlineName
        self.pilotName = pilotName
    }
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Flight ID : \(self.flightID ?? 0)"
        returnData += "\n Flight From: \(self.flightFrom ?? "")"
        returnData += "\n Flight TO: \(self.flightTo ?? "")"
        returnData += "\n Flight Date: \(self.flightDate ?? "")"
        returnData += "\n Airline ID: \(self.airlineID ?? 0)"
        returnData += "\n Airline Name: \(self.airlineName ?? "")"
        returnData += "\n Pilot Name: \(self.pilotName ?? "")"
        return returnData
        
    }
    
    //DICTIONARY
    var Airlines = [
        "airlineID":[01,02,03,04,05],
        "airlineName":["AirCanada","JetAirways","AirIndia","Indigo","SpiceJet"],
        "airlineType":["Domestic","International","Domestic","International","International"]
    ]
    
    var AirPlaneType=[
   // "airlinePlaneID":[01,02,03,04,05],
    "airplaneType": ["Boeing","Airbus","Jet"]
    
    ]
}




