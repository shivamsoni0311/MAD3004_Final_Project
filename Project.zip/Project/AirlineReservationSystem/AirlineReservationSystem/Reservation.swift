//
//  Reservation.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

typealias flightBooked = (flightID: Int, flights: Flight)

class Reservation : Passenger {
    
    var reservationID: Int = 0
    //private var reservationDesc : String
    private var resPassengerID : String
    private var resFlightID : String
    private var resDate : String
    private var resSeatNumber : String
    private var resStatus : ResStatusList?
    var set : Set<Int>
    private var resMealtype: String
    private var amount: Double
    private var bookedFlight : [flightBooked]
    private var dataHelper = DataHelper()
    
    override init() {
        self.reservationID = 0
    //  self.reservationDesc = ""
        self.resPassengerID = ""
        self.resFlightID = ""
        self.resDate = ""
        self.resSeatNumber = ""
        self.resStatus = ResStatusList.NoTickets
        self.resMealtype = ""
        self.amount = 0.0
        self.bookedFlight = []
        self.set = [0]
        super.init()
    }
    
    var ResID : Int{
        get { return self.reservationID }
        set{ self.reservationID = newValue}
    }
    var ResDate : String{
        get { return self.resDate }
        set{ self.resDate = newValue}
    }
    var ResStatus : ResStatusList?{
        get { return self.resStatus ?? ResStatusList.NoTickets }
        set{ self.resStatus = newValue}
    }
    
    func displayData() -> String {
        var returnData = ""
        returnData += "\n Reservation ID : \(self.reservationID)"
        //returnData += "\n Reservation Date: \(self.resDate )"
       //returnData += super.displayData()
        returnData += "\n Flight Details : "
        if !self.bookedFlight.isEmpty{
            for (_, flights) in self.bookedFlight{
                returnData += "\n \tFlights : \(flights.displayData())"
                
            }
        }else{
            returnData += "\n No Flights are available for booking. Sorry for the inconvenience"
        }
        returnData += "\n Booking Status : \(self.resStatus ?? ResStatusList.NoTickets)"
       // returnData += "\n Order Amount : \(self.orderAmount  ?? 0.0)"
        
        return returnData
        
    }
    
    func addFlight(){
        dataHelper.displayFlightdata()
        print("Please enter flight ID from the list to book flight : ")
        let selectedFlightID : Int = (Int)(readLine()!)!
        
        if let selectedFlightID = dataHelper.searchFlight(flightID: selectedFlightID){
            self.reservationID = selectedFlightID.flightID!
          //  self.OrderDate = Date()
            
            self.set.insert(selectedFlightID.flightID!)
            //self.bookedFlight += [(flightID: selectedFlightID)]
            self.resStatus = ResStatusList.Confimred
            
        }else{
            print("Sorry...The flight you entered is unavailable for booking")
        }
    }
    
}
